#!/bin/bash


fecha_actual=$(date +"%d %m %Y")

echo "Probando con la fecha actual: $fecha_actual"
./esLaborable.sh $fecha_actual
