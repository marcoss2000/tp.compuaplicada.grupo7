#!/bin/bash

ORIGEN="$1"
DESTINO="$2"

if [ ! -d "$ORIGEN" ] || [ ! -d "$DESTINO" ]; then
    echo "Error con los archivos ingresados"
    echo "Ingresar -h para recibir ayuda"
else
    FECHA_BACKUP=$(date +%Y%m%d)
    ARCHIVO_BACKUP="${ORIGEN}_bkp_${FECHA_BACKUP}.tar.gz"
fi

if [ �$1� == �-h� ]; then
	echo �Debe ingresar la direccion de los archivos que se quieran respaldar�
	exit 1
fi

function log() {
    HORA=$(date +"%H:%M:%S")
    MENSAJE="$1"
    echo "$HORA - $1"
}

function Enviar_mail() {
    mutt -s "Log de Backup" root -a "$DESTINO/$ARCHIVO_BACKUP" < /dev/null
}

if [ -d "$ORIGEN" ] && [ -d "$DESTINO" ]; then 
    log "Comenzando backup"
    tar -czf "$DESTINO/$ARCHIVO_BACKUP" "$ORIGEN"
    log "Backup completado: $ARCHIVO_BACKUP"
    log "Enviando correo electr�nico"
    Enviar_mail
fi