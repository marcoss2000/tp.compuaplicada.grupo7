#!/bin/bash

#Verifica que los servicios de services.txt funcionen
servicios=$(cat /opt/tp/scripts/services.txt)

service=$1

if [ ! -z "$service" ]; then
    if pgrep "$service" >/dev/null; then
        echo "$service se est� ejecutando"
    else
        echo "$service no se est� ejecutando"
    fi
else
    while IFS= read -r servicio; do
        if pgrep "$servicio" >/dev/null; then
            echo "$servicio se est� ejecutando" > /dev/null
        else
            msg="$servicio no se est� ejecutando"
            echo "$msg" | mail -s "$msg" root
        fi
    done < "/opt/tp/scripts/services.txt"
fi