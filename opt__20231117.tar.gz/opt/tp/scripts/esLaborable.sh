#!/bin/bash
#Uso esLaborable.sh <dia> <mes> <a�o>

DAY=$1
MONTH=$2
YEAR=$3

function esLaborable() {
    local day=$1
    local month=$2
    local year=$3

    local monthStr=$(date -d "$year-$month-$day" +%b) 
    local dow=$(date -d "$year-$month-$day" +%u)      
    local feriadoNacional=$(grep "$day:$monthStr" /opt/tp/scripts/feriados.txt)

    if [ -z "$feriadoNacional" ]; then
        if [ $dow -ne 6 ] && [ $dow -ne 7 ]; then
            echo "Es d�a laborable."
            return 0
        else
            echo "Es fin de semana."
            return 1
        fi
    else
        echo "Es Feriado Nacional:"
        echo "$feriadoNacional"
        return 1
    fi
}

esLaborable $DAY $MONTH $YEAR
	
